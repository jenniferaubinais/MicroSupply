Useful Notepad PlusPlus items

Source Cookifier is a handy extension that lets you quickly see functions, prototypes, variables, defines, etc.

http://sourceforge.net/projects/sourcecookifier/



Langs.xml file has the .ino extension added as a cpp extension and stdint.h types added so that they are nicely highlighted. Put a copy in your application data directory, for example:

C:\Documents and Settings\(user)\Application Data\Notepad++