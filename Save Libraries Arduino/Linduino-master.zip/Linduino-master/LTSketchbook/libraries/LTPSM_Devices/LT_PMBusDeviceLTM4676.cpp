#include "LT_PMBusDeviceLTM4676.h"

uint32_t LT_PMBusDeviceLTM4676::cap_ =  HAS_VOUT
                                        | HAS_VIN
                                        | HAS_IOUT
                                        | HAS_IIN
                                        | HAS_POUT
                                        | HAS_TEMP
                                        | HAS_DC
                                        | HAS_STATUS_WORD
                                        | HAS_STATUS_EXT
                                        ;