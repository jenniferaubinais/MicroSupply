#include "LT_PMBusDeviceLTC2975.h"

uint32_t LT_PMBusDeviceLTC2975::cap_ =  HAS_VOUT
                                        | HAS_VIN
                                        | HAS_IOUT
                                        | HAS_IIN
                                        | HAS_POUT
                                        | HAS_PIN
                                        | HAS_TEMP
                                        | HAS_STATUS_WORD
                                        | HAS_STATUS_EXT
                                        ;